import {Persona} from './persona';

let persona1 = new Persona("Juan","Lara");

console.log(persona1);
console.log(persona1.nombre);
console.log(persona1.apellido);
