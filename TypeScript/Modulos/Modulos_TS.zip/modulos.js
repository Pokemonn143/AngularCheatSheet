"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var persona_1 = require("./persona");
var persona1 = new persona_1.Persona("Juan", "Lara");
console.log(persona1);
console.log(persona1.nombre);
console.log(persona1.apellido);
